





# Development notes

Build and Install:

In the root directory of your package, run the following command to build a distribution package:
This will create a dist directory with a .tar.gz file.

```bash 
python setup.py sdist
```  

You can then install the package locally using pip:

```bash 
pip install dist/upb-1.0.0.tar.gz --force-reinstall
```