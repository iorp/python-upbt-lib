import os,sys,subprocess
import shutil
from setuptools import setup,find_packages
from Cython.Build import cythonize

class Build: 
    def __init__(self,config):
        self.config=config
        self.run()
 
    def run(self):
        args = Build.init_args(sys.argv) 
        print('RUNNING UPB:',args)  

        # help
        if "--help" in args:Build.show_help() # this exists 
        # if none then its all 
        if '--exe' not in args and '--pyd' not in args and  '--pyc' not in args:
            args = args + ['--exe','--pyd','--pyc','--remove-previous']
        # remove build and dist if -r
        if "--remove-previous" in args:r=Build.remove_prev()
        # run required stuff
        if "--exe" in args:r=Build.Builds.Exe.run(self.config.get('exe'))
        if "--pyd" in args:r=Build.Builds.Pyd.run(self.config.get('pyd'))
        if "--pyc" in args:r=Build.Builds.Pyc.run(self.config.get('pyc'))

        print(r)
    @staticmethod
    def run_subprocess(command_lines):
        
        
        if isinstance(command_lines, str):  command_lines = command_lines.split("&&")
    
        for command in command_lines:

            # try:
                # Run the command and capture the output
                process = subprocess.Popen(
                    command,
                    shell=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True, 
                )
    
                for line in process.stdout:
                    print(f"{line}", end='',flush=True)
                    
                
                for line in process.stderr:
                    print(f"{line}", end='',flush=True)
                
            
                
                # Wait for the command to complete
                process.wait()

                # Check if the command was successful
                if process.returncode != 0:
                    return {'error': True, 'code': process.returncode, 'stderr': str(process.stderr), 'command': command}
                return {'code':'RunSubprocessSuccess','error':False}
    @staticmethod
    def init_args(args):
        
        if '-h' in args:   sys.argv[sys.argv.index("-h")] ='--help'
        if '-r' in args:   sys.argv[sys.argv.index("-r")] ='--remove-previous'
        if '-e' in args:   sys.argv[sys.argv.index("-e")] ='--exe'
        if '-c' in args:   sys.argv[sys.argv.index("-c")] ='--pyc'
        if '-d' in args:   sys.argv[sys.argv.index("-d")] ='--pyd'
        
        
        return args
    @staticmethod
    def remove_prev():
        if "--remove-previous" in sys.argv: del sys.argv[sys.argv.index("--remove-previous")]  
        if os.path.exists('build'): shutil.rmtree('build')
        if os.path.exists('dist'): shutil.rmtree('dist')
    @staticmethod
    def show_help():
        print('help here')
        sys.exit()
    
    class Builds:
        class Pyd:
            @staticmethod
            def run(config):
                target_path = config.get('target')
               
                # build pyd
                if "--pyd" in sys.argv: del sys.argv[sys.argv.index("--pyd")]  
            
                print('Building inplace pyd compilation...')
                additional_params = ["build_ext", "--inplace"]
                py_files = Build.Builds.Pyd.find_py_files(target_path)
                ext_modules = Build.Builds.Pyd.create_extension_modules(py_files)

                setup(
                    ext_modules=ext_modules,
                    script_args=additional_params,
                    # Other setup configuration...
                )
             # functions
            def find_py_files(directory):
                py_files = []
                for root, dirs, files in os.walk(directory):
                    # Exclude directories starting with __
                    dirs[:] = [d for d in dirs if not d.startswith('__')]
                    
                    for file in files:
                        if file.endswith(".py") and not file.startswith('__init__'):
                            py_files.append(os.path.join(root, file))
                return py_files

            def create_extension_modules(py_files):
                ext_modules = cythonize(py_files)
                return ext_modules

        class Pyc:
            @staticmethod
            def run(config):
                # build pyc
                if "--pyc" in sys.argv: del sys.argv[sys.argv.index("--pyc")]  
                print('Building wheel on dist...')
                input = config.get('input','.')
                output = config.get('output','dist')
                name=  config.get('name','UnnamedPackage')
                version=  config.get('version','1.0.0')
                options=  config.get('options','')

                r = Build.run_subprocess(f'pip wheel --no-deps -w {output} {input}') # instead of DEPRECATED:'python setup.py bdist_wheel',
                if r.get('error'):return r 
                print('(Re)installing library...')
                r = Build.run_subprocess(f'pip install {output}/{name}-{version}-py3-none-any.whl {options}')
                if r.get('error'):return r 
        
        class Exe:
            @staticmethod
            def run(config):
                input = config.get('input')
                output = config.get('output','dist')
                options=config.get('options','')
                # Set the output
                options = options + ' --distpath ./'+output
                
                
                # build exe
                if "--exe" in sys.argv: del sys.argv[sys.argv.index("--exe")]  
                print('Building exe...')
                r = Build.run_subprocess(f'pyinstaller {input} {options}') 
                if r.get('error'):return r  
                try: 
                    if os.path.exists('.env'):  shutil.copy('.env', f'{output}/.env')
                except Exception as e:
                    return {'code':'BuilderEnvException','error':True}
    
                return {'code':'BuilderExeBuilt','updated':True}

